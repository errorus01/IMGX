// в релизе без чёрного консольного окна
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use eframe::egui;
use rayon::prelude::*;
use std::{
    collections::HashSet,
    fs::{self, File},
    io::{self, BufReader, Read, Seek, SeekFrom, Write},
    path::{Path, PathBuf},
    sync::{
        atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering::Relaxed},
        mpsc::{self, TryRecvError},
        Arc, Mutex,
    },
    thread,
    time::{Duration, Instant},
};

const SECTOR: u64 = 2048;
const ENTRY_SIZE: usize = 32;
const THREADS: usize = 4;
const CHUNK: usize = 4 * 1024 * 1024; // 4 МиБ на кусок

/// XOR-ключ каталога NEXT RP (период 32 байта = размер одной записи)
const KEY: &[u8; 32] = b"1e3tUl7jk1LbkOoPjIPYkLF7wmTneyKV";

// ───────────────────────── формат IMG ─────────────────────────

#[derive(Clone)]
struct Entry {
    offset: u64,
    size: u64,
    name: String,
}

fn invalid(msg: &str) -> io::Error {
    io::Error::new(io::ErrorKind::InvalidData, msg)
}

fn hex_dump(bytes: &[u8]) -> String {
    let mut s = String::new();
    for (i, line) in bytes.chunks(16).enumerate() {
        s.push_str(&format!("{:04X}  ", i * 16));
        for b in line {
            s.push_str(&format!("{b:02X} "));
        }
        s.push_str(&"   ".repeat(16 - line.len()));
        s.push(' ');
        for &b in line {
            s.push(if (0x20..0x7F).contains(&b) { b as char } else { '.' });
        }
        s.push('\n');
    }
    s
}

/// Вдруг это вообще не IMG, а переименованный архив
fn sniff(head: &[u8]) -> Option<&'static str> {
    match head {
        [b'P', b'K', 3, 4, ..] => Some("ZIP"),
        [b'R', b'a', b'r', b'!', ..] => Some("RAR"),
        [b'7', b'z', 0xBC, 0xAF, ..] => Some("7-Zip"),
        [0x1F, 0x8B, ..] => Some("GZIP"),
        [b'M', b'Z', ..] => Some("EXE/DLL"),
        _ => None,
    }
}

fn parse_entries(raw: &[u8], file_len: u64) -> Vec<Entry> {
    let mut entries = Vec::with_capacity(raw.len() / ENTRY_SIZE);
    for chunk in raw.chunks_exact(ENTRY_SIZE) {
        let offset = u32::from_le_bytes(chunk[0..4].try_into().unwrap()) as u64 * SECTOR;
        let streaming = u16::from_le_bytes(chunk[4..6].try_into().unwrap()) as u64;
        let in_archive = u16::from_le_bytes(chunk[6..8].try_into().unwrap()) as u64;
        let sectors = if streaming != 0 { streaming } else { in_archive };

        let name_bytes = &chunk[8..32];
        let end = name_bytes.iter().position(|&b| b == 0).unwrap_or(24);
        let name = String::from_utf8_lossy(&name_bytes[..end]).into_owned();

        let size = (sectors * SECTOR).min(file_len.saturating_sub(offset));
        entries.push(Entry { offset, size, name });
    }
    entries
}

/// Проверка, что после расшифровки имена похожи на имена
fn names_look_valid(raw: &[u8]) -> bool {
    let mut total = 0;
    let mut good = 0;
    for c in raw.chunks_exact(ENTRY_SIZE).take(64) {
        total += 1;
        let n = &c[8..32];
        let z = n.iter().position(|&b| b == 0).unwrap_or(24);
        if z > 0 && n[..z].iter().all(|&b| (0x20..0x7F).contains(&b)) {
            good += 1;
        }
    }
    total == 0 || good * 10 >= total * 8
}

/// Возвращает (записи, был_ли_каталог_зашифрован)
fn read_directory<R: Read + Seek>(r: &mut R) -> io::Result<(Vec<Entry>, bool)> {
    let file_len = r.seek(SeekFrom::End(0))?;
    r.seek(SeekFrom::Start(0))?;

    let mut head = [0u8; 8];
    r.read_exact(&mut head)?;

    if &head[..4] != b"VER2" {
        let hint = sniff(&head)
            .map(|s| format!(" (похоже на {s})"))
            .unwrap_or_default();
        return Err(invalid(&format!("нет сигнатуры VER2{hint}")));
    }

    // 1) обычный (нешифрованный) IMG
    let plain_count = u32::from_le_bytes(head[4..8].try_into().unwrap()) as u64;
    if plain_count > 0 && 8 + plain_count * ENTRY_SIZE as u64 <= file_len {
        let mut raw = vec![0u8; plain_count as usize * ENTRY_SIZE];
        r.read_exact(&mut raw)?;
        return Ok((parse_entries(&raw, file_len), false));
    }

    // 2) каталог NEXT RP: XOR ключом, количество записей шифруется началом ключа
    let mut cb = [head[4], head[5], head[6], head[7]];
    for (i, b) in cb.iter_mut().enumerate() {
        *b ^= KEY[i];
    }
    let count = u32::from_le_bytes(cb) as u64;
    let need = 8 + count * ENTRY_SIZE as u64;
    if need > file_len {
        return Err(invalid(&format!(
            "после расшифровки: {count} записей ({need} байт каталога), а файл {file_len} байт. У этого архива другой ключ/формат"
        )));
    }

    let mut raw = vec![0u8; count as usize * ENTRY_SIZE];
    r.read_exact(&mut raw)?;
    for (i, b) in raw.iter_mut().enumerate() {
        *b ^= KEY[i % 32];
    }

    if !names_look_valid(&raw) {
        return Err(invalid(
            "каталог расшифрован, но имена выглядят как мусор: у этого архива, видимо, другой ключ",
        ));
    }

    Ok((parse_entries(&raw, file_len), true))
}

/// Читаем начало первого DFF/TXD и смотрим, не зашифрованы ли сами данные
fn data_probe(img: &Path, entries: &[Entry]) -> String {
    let Some(e) = entries.iter().find(|e| {
        let n = e.name.to_lowercase();
        (n.ends_with(".dff") || n.ends_with(".txd")) && e.size >= 16
    }) else {
        return String::new();
    };

    let mut b = [0u8; 16];
    let read = File::open(img).and_then(|mut f| {
        f.seek(SeekFrom::Start(e.offset))?;
        f.read_exact(&mut b)
    });
    if let Err(err) = read {
        return format!("Проверка данных не удалась: {err}");
    }

    let id = u32::from_le_bytes([b[0], b[1], b[2], b[3]]);
    let hex: Vec<String> = b.iter().map(|x| format!("{x:02X}")).collect();
    if id == 0x10 || id == 0x16 {
        format!("Данные ({}): чистый RenderWare, расшифровка не нужна ✅", e.name)
    } else {
        format!(
            "Данные ({}): НЕ похожи на DFF/TXD, скорее всего тоже зашифрованы ⚠️\nПервые 16 байт: {}",
            e.name,
            hex.join(" ")
        )
    }
}

/// Только имя файла, без "../" и путей
fn safe_name(name: &str) -> Option<String> {
    Path::new(name)
        .file_name()
        .filter(|n| !n.is_empty())
        .map(|n| n.to_string_lossy().into_owned())
}

// ───────────────────────── параллельная распаковка ─────────────────────────

struct Task {
    offset: u64,
    size: u64,
    out: PathBuf,
}

#[derive(Default)]
struct Progress {
    bytes: AtomicU64,
    files: AtomicUsize,
    cancel: AtomicBool,
}

#[derive(Default)]
struct Report {
    ok: usize,
    skipped: usize,
    failed: Vec<String>,
    cancelled: bool,
    secs: f64,
    bytes: u64,
}

/// Уникальные имена, чтобы потоки не писали в один файл
fn build_tasks(items: &[&Entry], out_dir: &Path) -> (Vec<Task>, usize) {
    let mut seen: HashSet<String> = HashSet::new();
    let mut tasks = Vec::with_capacity(items.len());
    let mut skipped = 0;

    for e in items {
        let Some(base) = safe_name(&e.name) else {
            skipped += 1;
            continue;
        };

        let mut name = base.clone();
        let mut n = 1;
        while !seen.insert(name.to_lowercase()) {
            name = match base.rsplit_once('.') {
                Some((stem, ext)) => format!("{stem}_dup{n}.{ext}"),
                None => format!("{base}_dup{n}"),
            };
            n += 1;
        }

        tasks.push(Task {
            offset: e.offset,
            size: e.size,
            out: out_dir.join(name),
        });
    }
    (tasks, skipped)
}

/// Ok(true) — скопировано, Ok(false) — отменено
fn copy_one(img: &Path, t: &Task, p: &Progress) -> io::Result<bool> {
    let mut src = File::open(img)?;
    src.seek(SeekFrom::Start(t.offset))?;
    let mut dst = File::create(&t.out)?;
    let mut buf = vec![0u8; CHUNK];
    let mut left = t.size;

    while left > 0 {
        if p.cancel.load(Relaxed) {
            drop(dst); // на Windows нельзя удалить открытый файл
            let _ = fs::remove_file(&t.out);
            return Ok(false);
        }
        let n = left.min(CHUNK as u64) as usize;
        src.read_exact(&mut buf[..n])?;
        dst.write_all(&buf[..n])?;
        left -= n as u64;
        p.bytes.fetch_add(n as u64, Relaxed);
    }
    Ok(true)
}

fn run_job(img: PathBuf, tasks: Vec<Task>, skipped: usize, progress: Arc<Progress>) -> Report {
    let started = Instant::now();
    let errors: Mutex<Vec<String>> = Mutex::new(Vec::new());

    match rayon::ThreadPoolBuilder::new().num_threads(THREADS).build() {
        Ok(pool) => pool.install(|| {
            tasks.par_iter().for_each(|t| {
                if progress.cancel.load(Relaxed) {
                    return;
                }
                match copy_one(&img, t, &progress) {
                    Ok(true) => {
                        progress.files.fetch_add(1, Relaxed);
                    }
                    Ok(false) => {}
                    Err(e) => errors
                        .lock()
                        .unwrap()
                        .push(format!("{}: {e}", t.out.display())),
                }
            });
        }),
        Err(e) => errors
            .lock()
            .unwrap()
            .push(format!("не создался пул потоков: {e}")),
    }

    Report {
        ok: progress.files.load(Relaxed),
        skipped,
        failed: errors.into_inner().unwrap(),
        cancelled: progress.cancel.load(Relaxed),
        secs: started.elapsed().as_secs_f64(),
        bytes: progress.bytes.load(Relaxed),
    }
}

// ───────────────────────── интерфейс ─────────────────────────

struct Job {
    progress: Arc<Progress>,
    rx: mpsc::Receiver<Report>,
    total_bytes: u64,
    total_files: usize,
    started: Instant,
}

fn fmt_size(b: u64) -> String {
    const KB: f64 = 1024.0;
    let b = b as f64;
    if b >= KB * KB * KB {
        format!("{:.2} ГБ", b / (KB * KB * KB))
    } else if b >= KB * KB {
        format!("{:.1} МБ", b / (KB * KB))
    } else {
        format!("{:.1} КБ", b / KB)
    }
}

#[derive(Default)]
struct ImgApp {
    path: Option<PathBuf>,
    entries: Vec<Entry>,
    selected: Vec<bool>,
    filter: String,
    status: String,
    data_note: String,
    dump: Option<String>,
    job: Option<Job>,
}

impl ImgApp {
    fn new(_cc: &eframe::CreationContext<'_>) -> Self {
        Self {
            status: "Открой .img или просто перетащи файл в окно".into(),
            ..Default::default()
        }
    }

    fn open(&mut self, path: PathBuf) {
        let result = File::open(&path).and_then(|f| read_directory(&mut BufReader::new(f)));
        match result {
            Ok((entries, encrypted)) => {
                self.data_note = data_probe(&path, &entries);
                self.status = format!(
                    "Загружено файлов: {}{}",
                    entries.len(),
                    if encrypted { " (каталог расшифрован)" } else { "" }
                );
                self.selected = vec![false; entries.len()];
                self.entries = entries;
                self.path = Some(path);
                self.dump = None;
            }
            Err(e) => {
                self.status = format!("Ошибка: {e}");
                self.data_note.clear();
                // первые 64 байта для диагностики
                let mut buf = Vec::new();
                if let Ok(f) = File::open(&path) {
                    let _ = f.take(64).read_to_end(&mut buf);
                }
                self.dump = Some(hex_dump(&buf));
            }
        }
    }

    fn start_extract(&mut self, ctx: &egui::Context, only_selected: bool) {
        let Some(img) = self.path.clone() else { return };
        let Some(dir) = rfd::FileDialog::new().set_title("Куда распаковать?").pick_folder() else {
            return;
        };

        if let Err(e) = fs::create_dir_all(&dir) {
            self.status = format!("Не могу создать папку: {e}");
            return;
        }

        let items: Vec<&Entry> = self
            .entries
            .iter()
            .zip(&self.selected)
            .filter(|(_, &sel)| sel || !only_selected)
            .map(|(e, _)| e)
            .collect();

        let (tasks, skipped) = build_tasks(&items, &dir);
        let total_bytes = tasks.iter().map(|t| t.size).sum();
        let total_files = tasks.len();

        let progress = Arc::new(Progress::default());
        let (tx, rx) = mpsc::channel();

        {
            let progress = Arc::clone(&progress);
            let ctx = ctx.clone();
            thread::spawn(move || {
                let report = run_job(img, tasks, skipped, progress);
                let _ = tx.send(report);
                ctx.request_repaint(); // будим UI, когда закончили
            });
        }

        self.status = format!("Распаковка в {THREADS} потока...");
        self.job = Some(Job {
            progress,
            rx,
            total_bytes,
            total_files,
            started: Instant::now(),
        });
    }

    fn poll_job(&mut self) {
        let Some(job) = &self.job else { return };
        match job.rx.try_recv() {
            Ok(r) => {
                let speed = if r.secs > 0.0 {
                    r.bytes as f64 / r.secs / 1_048_576.0
                } else {
                    0.0
                };
                self.status = if r.cancelled {
                    format!("Отменено. Успели распаковать: {} файлов", r.ok)
                } else if r.failed.is_empty() {
                    format!(
                        "Готово: {} файлов, {} за {:.1} с ({:.0} МБ/с){}",
                        r.ok,
                        fmt_size(r.bytes),
                        r.secs,
                        speed,
                        if r.skipped > 0 {
                            format!(", пропущено {} (кривые имена)", r.skipped)
                        } else {
                            String::new()
                        },
                    )
                } else {
                    format!(
                        "Готово с ошибками: ок {}, ошибок {}. Первая: {}",
                        r.ok,
                        r.failed.len(),
                        r.failed[0]
                    )
                };
                self.job = None;
            }
            Err(TryRecvError::Disconnected) => {
                self.status = "Фоновый поток упал, распаковка прервана".into();
                self.job = None;
            }
            Err(TryRecvError::Empty) => {}
        }
    }
}

impl eframe::App for ImgApp {
    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        let ctx = ui.ctx().clone();
        self.poll_job();
        let busy = self.job.is_some();

        // drag & drop файла в окно (пока идёт распаковка игнорим)
        let dropped = ctx.input(|i| i.raw.dropped_files.clone());
        if !busy {
            if let Some(p) = dropped.into_iter().find_map(|f| f.path) {
                self.open(p);
            }
        }

        egui::CentralPanel::default().show(ui, |ui| {
            let loaded = !self.entries.is_empty();
            let sel_count = self.selected.iter().filter(|&&s| s).count();

            // ── кнопки ──
            ui.horizontal_wrapped(|ui| {
                if ui
                    .add_enabled(!busy, egui::Button::new("📂 Открыть IMG"))
                    .clicked()
                {
                    if let Some(p) = rfd::FileDialog::new()
                        .add_filter("GTA IMG", &["img"])
                        .add_filter("Все файлы", &["*"])
                        .pick_file()
                    {
                        self.open(p);
                    }
                }
                if ui
                    .add_enabled(loaded && !busy, egui::Button::new("📦 Распаковать всё"))
                    .clicked()
                {
                    self.start_extract(&ctx, false);
                }
                if ui
                    .add_enabled(
                        sel_count > 0 && !busy,
                        egui::Button::new(format!("✅ Выбранные ({sel_count})")),
                    )
                    .clicked()
                {
                    self.start_extract(&ctx, true);
                }
                if busy && ui.button("⛔ Отмена").clicked() {
                    if let Some(j) = &self.job {
                        j.progress.cancel.store(true, Relaxed);
                    }
                }
            });

            // ── прогресс ──
            if let Some(job) = &self.job {
                let done = job.progress.bytes.load(Relaxed);
                let files = job.progress.files.load(Relaxed);
                let frac = if job.total_bytes > 0 {
                    (done as f32 / job.total_bytes as f32).min(1.0)
                } else {
                    0.0
                };
                let secs = job.started.elapsed().as_secs_f64().max(0.001);
                let speed = done as f64 / secs / 1_048_576.0;

                ui.add(
                    egui::ProgressBar::new(frac)
                        .show_percentage()
                        .text(format!(
                            "{} / {}   |   файлов {}/{}   |   {:.0} МБ/с",
                            fmt_size(done),
                            fmt_size(job.total_bytes),
                            files,
                            job.total_files,
                            speed
                        )),
                );
                ctx.request_repaint_after(Duration::from_millis(100));
            }

            if let Some(p) = &self.path {
                ui.label(format!("Архив: {}", p.display()));
            }
            ui.separator();

            // ── поиск + выделение ──
            let f = self.filter.to_lowercase();
            let visible: Vec<usize> = self
                .entries
                .iter()
                .enumerate()
                .filter(|(_, e)| f.is_empty() || e.name.to_lowercase().contains(&f))
                .map(|(i, _)| i)
                .collect();

            ui.horizontal(|ui| {
                ui.label("🔍");
                ui.text_edit_singleline(&mut self.filter);
                if ui
                    .add_enabled(loaded, egui::Button::new("Выделить видимые"))
                    .clicked()
                {
                    for &i in &visible {
                        self.selected[i] = true;
                    }
                }
                if ui
                    .add_enabled(loaded, egui::Button::new("Снять всё"))
                    .clicked()
                {
                    self.selected.iter_mut().for_each(|s| *s = false);
                }
                ui.label(format!(
                    "показано {} из {}",
                    visible.len(),
                    self.entries.len()
                ));
            });
            ui.separator();

            // ── список ──
            let row_h = ui.text_style_height(&egui::TextStyle::Body) + 6.0;
            let mut reserve = 28.0;
            if !self.data_note.is_empty() {
                reserve += 40.0;
            }
            if self.dump.is_some() {
                reserve += 160.0;
            }
            let list_h = (ui.available_height() - reserve).max(80.0);

            egui::ScrollArea::vertical()
                .max_height(list_h)
                .auto_shrink([false, false])
                .show_rows(ui, row_h, visible.len(), |ui, range| {
                    for row in range {
                        let i = visible[row];
                        let e = &self.entries[i];
                        ui.horizontal(|ui| {
                            ui.checkbox(&mut self.selected[i], "");
                            ui.add_sized([220.0, row_h], egui::Label::new(&e.name).truncate());
                            ui.label(fmt_size(e.size));
                        });
                    }
                });

            ui.separator();
            ui.label(&self.status);
            if !self.data_note.is_empty() {
                ui.label(&self.data_note);
            }

            // ── hex-дамп при ошибке открытия ──
            if let Some(d) = self.dump.clone() {
                ui.separator();
                ui.horizontal(|ui| {
                    ui.label("Первые 64 байта файла:");
                    if ui.button("Копировать").clicked() {
                        ui.ctx().copy_text(d.clone());
                    }
                });
                ui.label(egui::RichText::new(d).monospace());
            }
        });
    }
}

fn main() -> eframe::Result<()> {
    let options = eframe::NativeOptions {
        renderer: eframe::Renderer::Glow,
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([700.0, 680.0])
            .with_min_inner_size([460.0, 320.0])
            .with_drag_and_drop(true),
        ..Default::default()
    };
    eframe::run_native(
        "IMG Extractor",
        options,
        Box::new(|cc| Ok(Box::new(ImgApp::new(cc)))),
    )
}